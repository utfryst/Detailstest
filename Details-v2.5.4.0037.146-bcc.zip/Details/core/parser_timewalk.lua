local Details = _G.Details
local _
local helloWorld